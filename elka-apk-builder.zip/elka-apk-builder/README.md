# ELKA Finance — compiler ton propre APK gratuitement

Ce projet remplace Manus pour compiler tes APK : gratuit, illimité, automatique.

## Installation (à faire UNE SEULE FOIS)

1. **Créer un compte GitHub** (gratuit) : https://github.com/signup si tu n'en as pas
2. **Créer un nouveau repository** (dépôt) — bouton vert "New" sur github.com
   - Nom : `elka-finance-apk` (ou ce que tu veux)
   - Laisse-le **privé** si tu veux que ton code reste secret
3. **Envoyer tout ce dossier** (`elka-apk-builder`) dans ce repository :
   - Le plus simple : sur la page du repo vide, clique "uploading an existing file"
     et glisse-dépose TOUS les fichiers/dossiers de ce dossier (garde bien la
     structure : `.github/workflows/build-apk.yml` doit rester à cet endroit)
   - Ou si tu connais git : `git init`, `git add .`, `git commit -m "init"`,
     `git remote add origin <url-de-ton-repo>`, `git push -u origin main`

## À chaque fois que tu modifies ton appli (le workflow normal)

1. Remplace le fichier `www/index.html` par ta nouvelle version d'ELKA Finance
2. Envoie ce fichier modifié sur GitHub (upload ou `git push`)
3. Va dans l'onglet **"Actions"** de ton repository sur GitHub
4. Tu verras "Build APK ELKA Finance" tourner automatiquement (2-5 minutes)
5. Une fois terminé (coche verte ✅), clique dessus → en bas de la page,
   section **"Artifacts"** → télécharge `ELKA-Finance-APK`
6. C'est un zip contenant `app-debug.apk` — c'est ton APK, installable direct
   sur un téléphone Android (il faudra peut-être autoriser "sources inconnues")

**C'est tout. Zéro paiement, zéro Manus, illimité.**

## Pour les notifications (WorkManager custom qu'on a spec pour Manus)

Ce scaffold utilise Capacitor plutôt que le wrapper WebView fait main. Deux options :

- **Option simple** : utiliser le plugin `@capacitor/local-notifications` déjà
  inclus dans `package.json` — il gère les notifications locales facilement en
  JavaScript directement (pas besoin de code Kotlin séparé), mais pour une
  vérification périodique en arrière-plan (comme le taux de change toutes les
  1h appli fermée), il faut ajouter le plugin `@capacitor/background-runner`
  (gratuit aussi, se rajoute avec `npm install @capacitor/background-runner`)

- **Option avancée** : garder le code Kotlin natif du document
  `specs-notifications-manus.md` — ça marche aussi dans un projet Capacitor,
  il faut juste le placer dans `android/app/src/main/java/...` après le premier
  `npx cap add android` (le dossier `android/` n'existe qu'après le premier
  build, GitHub Actions le crée automatiquement)

Dis-moi laquelle des deux tu préfères et je t'écris le détail.

## Important — l'APK généré n'est pas signé pour le Play Store

`assembleDebug` produit un APK de test, installable directement sur un
téléphone (parfait pour toi et tes utilisateurs actuels), mais **pas publiable
sur Google Play Store** tel quel (il faudrait le signer avec une clé, une
étape en plus qu'on ajoutera si un jour tu veux publier sur le Store).
